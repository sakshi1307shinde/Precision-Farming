<?php
include("header.php");
?>

<html>
  <head>
    <style>
     *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
}
.guidance{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  
.info{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  
.info1{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  

      </style>
  </head>
</html>

<div class="container-fluid">
<div class="guidance">

<div class="row">
<marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee>
<img src="images\14.jpg" width=100% height=300px>
</div></div></div>
<h1 align="center">Land Preparation</h1>
<div class="info">
<p align=justify>Land Preparation for Onion Farming
Onion can grow in almost all types of soils. Generally, the seeds are sowed in nursery and the seedlings are transplanted after approximately 30-40 days. Before transplantation the field must be ploughed properly to get rid of the soil clods and unwanted debris. Vermicomposting (approximately 3 tonnes per acre) or poultry manure can be incorporated. This is done during the last ploughing.

After ploughing the fields are levelled and beds are prepared. Depending on the season, the beds maybe flat beds or broad bed furrows. Flat beds are 1.5-2 meter in width and 4-6 meter in length. Broad bed furrows have a height of 15 cm and top width of 120 cm. The furrows are 45 cm deep so as to get the right spacing. Onions are cultivated in broad bed furrows during kharif season since it is easier for excess water to drain out through the furrows. It also facilitates aeration and reduces occurrence of Anthracnose disease. Flat beds are made if onion cultivation is done during rabi season. Flat beds for kharif can cause water logging.</p>
</div>
<div><h1 align="center">Onion Storage</h1></div>
<div class="info1">
<p align=justify>
Onion storing in jute bag
Generally, onion bulbs harvested in rabi season have better shelf-life than kharif. Light red onion varieties have better storage potential than the dark red varieties. They are stored in jute bags or wooden baskets. They are also stored in netted bags. This is important because onions emit gas which if may lead to rotting if not allowed to escape. Optimum temperature for storage is 30-35˚C with 65-70% relative humidity.

Cold storage increases the shelf life. The loss of crop after storing in cold for six months has been found to be 5%. However, extremely low temperature (less than -2⁰C) can lead to freezing injury. A high temperature can cause rotting. A gradual decrease of temperature prevents microbial decay.
</p></div>
<?php
include("footer.php");
?>
