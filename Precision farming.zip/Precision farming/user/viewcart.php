<html><head>
<style>
            *{
                margin:auto auto;
                padding: auto auto;
            }
            .column{
           margin:auto auto;
           margin-left:400px;
           width:700px;
           color:black;
           font-size:18px;
           font-weight:700px;
            }
            .row{
                margin:auto auto;
                margin-left:400px;
                margin-top:10px;
                width:700px;
               color:black;
               font-size:18px;
               font-weight:700px;
            }
           
           
        </style>
</head></html>





<?php
session_start();
include("header.php");
?>



<div class="column">
  <marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee>
<img src="images\14.jpg" width=100% height=300px>
<h1 align=center>Your Cart</h1>
<div class="row">
    <table class=table>
        <thread>
            <tr><th>Actions</th><th>Image</th><th>Productid</th><th>price</th><th>quantity</th><th>amount</th></tr>
        </thread>
    </table>
    <?php
    include("connection.php");
    $u=$_SESSION["username"];
    $q="select username,cart.productid,cart.price,cart.quantity,cart.amount,image from cart,uploadproduct where cart.productid=uploadproduct.productid and cart.username='$u'";
    $rs=mysqli_query($cn,$q);
    while($a=mysqli_fetch_array($rs))
    {
        extract($a);
        echo"<tr>";
        echo"<td><a href=del.php?uname=$u&productid=$productid>DELETE</a></td> &nbsp&nbsp&nbsp&nbsp&nbsp<td><img src='images/$image'width=100 height=100></td> &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<td>$productid</td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<td>$price Rs</td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<td>$quantity kg</td>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<td>$amount  Rs</td>";
        echo"</tr>";
    }
    $total=0;
    $q="select sum(amount) from cart where username='$u'";
    $rs=mysqli_query($cn,$q);
    if($a=mysqli_fetch_array($rs))
    {
        $total=$a[0];
    }
    echo"<center><tr><td></td><td></td><td></td><td></td><td></td><b>Total Amount</b><td></td><td></td><b>$total</b></td></tr></center>";
    mysqli_close($cn);

    ?>
    </tbody>
</table>
<br>
<center><a class="btn btn-primary" href='payment.php?amount=<?php echo $total; ?>'>Confirm Order and Proceed to payment</a></center>
</div>



<?php
include("footer.php");
?>