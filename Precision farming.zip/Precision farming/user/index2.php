<?php
include("header.php");
?>

<html>
  <head>
    <style>
     *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
}

      </style>
  </head>
</html>

<div class="container-fluid">
<div class="row">
<div class="col col-sm-12">
<img src="images\9.jpg" width=100% height=300px>
</div></div>
<h1 align=center><b>our services</b></h1>
<div class="row">
  <marquee left>
    <div class="col-sm-4">
      <div class="thumbnail">
        <a href="product.php" target="_blank">
          <img src="images/7.jpg" alt="Lights" style="width:100%">
          <div class="caption">
           <h3 align=center><p><b>Our Products</b></p></h3>
          </div>
        </a>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <a href="guidance.php" target="_blank">
          <img src="images/8.jpg" alt="Nature" style="width:100%">
          <div class="caption">
           <h3 align=center><p><b>Guidance</b></p></h3>
          </div>
        </a>
      </div>
    </div>
    <div class="col-sm-4">
      <div class="thumbnail">
        <a href="feedback.php" target="_blank">
          <img src="images/4.jpg" alt="Fjords" style="width:100%">
          <div class="caption">
                    <h3 align=center>  <p><b>Feedback</b></p></h3>
          </div>
        </a>
      </div>
    </div>
  </div>
</marquee>
</div>

<?php
include("footer.php");
?>
