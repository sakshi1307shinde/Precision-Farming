<?php
include("header.php");
?>
<html><head> <style>
     *{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
}
.row{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
.info{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
.info1{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
.info2{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
.info3{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
.info4{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}
</style>  </head>
<body>


<div class="container-fluid">
<div class="row">
<div class="col col-sm-13">
<marquee direction=left> <h3><b>Shetkari Producer Company's Precision Farming</b></h3></marquee>
<img src="images\28.jpg" width=100% height=300px>
</div></div>
<div>
   <h1 align=center> Onion Harvesting</h1>
</div>
<div class="info">
<p>Onion harvesting is done when the still green tops start drooping. The plants are gently pulled out from the soil. However, 10-15 days before harvesting irrigation of the field is stopped. The crop is also sprayed with 1000 ppm carbendazim 30 days before harvest. This helps increase the shelf-life of the crop. The bulbs are cleaned and dried in shade for 4 days.</p>
</div>
<div><h1 align=center>Planting Onion</h1></div>
<div class="info1">
        <p>Planting Onion
Onion seeds are first sown in nurseries and later transplanted to the open fields. Nursery management and transplanting are hence the most important steps in onion cultivation.
<div><h1 align=center>Nursery Management</h1></div>
<div class="info2">
<p>"Seed
For one acre of onion plantation, seedlings can be prepared in 0.12 acre of area. The nursery field must be ploughed well and made free of clods. The soil must be reduced to finer particles so as to hold enough water. The filed must be clear of stones, debris and weeds. Just like the main field preparation, farm yard manure (half ton) must be applied at the time of last ploughing. Raised beds are recommended for nursery preparation. This is because flat beds allow water movement from end to end. There is a risk of seeds getting washed away in the process. The beds must be raised to a height of 10-15 cm, width of 1 m and length as per convenience. Keep a distance of at least 30 cm between the beds to allow easy drainage of excess water. 0.2% Pendimethalin is used for controlling the weeds in the nursery. 2-4 Kg of seeds is required for one acre of onion cultivation.</p>
</div>
<div><h1 align=center>Seed Preparation</h1></div>
<div class="info3">
<p>
Seeds are treated with 2g/Kg of thiram or Trichoderma viride to prevent damage from damping off diseases. The seed distance is maintained at 50-75mm to facilitate easy weeding and removal of seedlings for transplantation. The seeds are covered with farm yard manure after sowing and watered slightly.
</p></div>
<div><h1 align=center>Transplantation</h1></div>
<div class="info4">
<p>
Transplantation
Onion seeds are first grown in nurseries and then the seedlings are transplanted to the fields 30-40 days later. 3-4 Kg seeds are needed for one acre of field. Early transplantation yields more bulbs. During transplantation, care must be taken to avoid over and under-aged seedlings. The following process is followed during transplantation:

About one-third of the top of the seedling is cut
Roots are dipped in 0.1% carbendazim solution for two hours to prevent fungal diseases
The seedlings are transplanted into prepared beds at a distance of 10 cm between plants.</p></div>
</div>
</body>
</html>

<?php
include("footer.php");
?>