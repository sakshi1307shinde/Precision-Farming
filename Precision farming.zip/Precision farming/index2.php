<?php
include("header.php");
?>



<div class="container-fluid">
<div class="row">
<div class="col-sm-12">
  <h2><b><center>Precision farming...</center></b></h2>
<img src="images\9.jpg" width=100% height=300px>
</div></div>
<h1 align=center><b>Our Services</b></h1>
<marquee behaviour=right>
<div class="row">
 
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="aboutus.php" target="_blank">
          <img src="images/7.jpg" style="width:100%">
          <div class="caption">
           <h1 align=center><p>About Us</p></h1>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="product.php" target="_blank">
          <img src="images/8.jpg" style="width:100%">
          <div class="caption">
          <h1 align=center><p>Our Products </p></h1>
          </div>
        </a>
      </div>
    </div>
    <div class="col-md-4">
      <div class="thumbnail">
        <a href="contactus.php" target="_blank">
          <img src="images/4.jpg"  style="width:100%">
          <div class="caption">
            <h1 align=center><p>Contact Us</p></h1>
          </div>
        </a>
      </div>
    </div>
</marquee>
<h1 align=center>Contact us</h1>
  <p align=center><span class="glyphicon glyphicon-envelope"><b> : precisionfarming13@gmail.com</b></span></p>
  <p align=center> <span class="glyphicon glyphicon-earphone"><b> : 9763540338 </b></span></p>

  </div>
  </div>

<?php
include("footer.php");
?>
