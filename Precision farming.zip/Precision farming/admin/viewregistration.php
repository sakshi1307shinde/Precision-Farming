<?php
include("header1.php");
?>

<h1 align=center>Recent Registrations</h1>
 <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Address</th>
        <th>Email id</th>
        <th>Contact No</th>
        <th>Password</th>
        <th>security Question</th>
        <th>security Answer</th>
      </tr>
    </thead>
    <tbody>
<?php
include("connection.php");

$rs=mysqli_query($cn,"select * from registration");
while($a=mysqli_fetch_array($rs))
{
 extract($a);

echo "<tr><td>$Name</td><td>$Address</td><td>$EmailId</td><td>$ContactNo</td><td>$Password</td><td>$securityques</td><td>$securityanswer</td> </tr>";
}
?>
    </tbody>
  </table>
<?php
include("footer.php");
?>