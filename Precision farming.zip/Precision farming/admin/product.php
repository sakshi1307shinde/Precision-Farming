<html><head>
  <style> 


*{
  margin: 0;
  padding: 0;
}
    

.Product{
        margin:auto auto;
        margin-top:30px;
        width:600px;
        color:black;
        font-size:18px;
        font-weight:700px;
}  
.price{
        margin:auto auto;
        margin-top:20px;
        width:600px;
        color:black;
        font-size:15px;
        font-weight:100px;
}  
.img{
        margin:auto auto;
        margin-top:20px;
        width:600px;
        color:black;
        font-size:15px;
        font-weight:100px;
}  
.btn{
        margin:auto auto;
        margin-top:20px;
        margin-left:300px;
        width:300px;
        color:black;
        font-size:15px;
        font-weight:100px;
}  
.tbl{
        margin:auto auto;
        margin-top:20px;
       
        width:600px;
        color:black;
        font-size:15px;
        font-weight:100px;
}  

</style></head></html>
<?php
include("header1.php");
?>
<div class="product">
<h1 align =center>Add Products</h1>
<form id=frmreg method="post" name="myform" enctype="multipart/form-data">
  <div class="productnm">
    <label for="email">Product Name:</label>
    <input type="name" class="form-control" name="nm">
  </div>
  <div class="productid">
    <label for="pwd">Product Id:</label>
    <input type="productid" class="form-control" name="pid">
  </div>
</div>
<br>
<div class="price">
    <label for="price">Price:</label>
    <input type="price" class="form-control" name="prc">
  </div>
<div class="img">
<span ckass="input-group-addon"><i class="glyphicon glyphicon-camera"></i><span>
<input ng-model="address" id="address" type="file" class="form-control" name="file1" placeholder="Select Image" required>
  </div>
<br>
<div class="btn">
  <button type="submit" class="btn btn-primary" id="btnsub" name=btnsub>Submit</button>
</div>
</form>
<div class="tbl">
<h2>Products</h2>

<table class=table>
<thead>
<tr>
<th>Actions</th><th>productid</th><th>price</th><th>Image</th>
</tr>
</thead>
<tbody>
</div>
<?php
include("connection.php");
$q="select * from uploadproduct";
$rs=mysqli_query($cn,$q);
while($a=mysqli_fetch_array($rs))
{
extract($a);
echo "<tr>";
echo "<td><a href=del3.php?Productid=$productid>Delete</a> <a href=update.php?Productid=$productid>Update</a></td><td>$productid</td><td>$price</td><td><img src='../images/$image' width=100
height=100></td>";
echo "</tr>";
}
?>
</tbody>
</table>
<?php
include("footer.php");
if(isset($_POST['btnsub']))
{
extract($_POST);
$fn=$_FILES['file1']['name'];
$s=$_FILES['file1']['size'];
$tnm=$_FILES['file1']['tmp_name'];
$ptr1=fopen($tnm,"r");
$ptr2=fopen("../images/$fn","w");
$data=fread($ptr1,$s);
fwrite($ptr2,$data);
fclose($ptr1);
fclose($ptr2);
include("connection.php");
$q="insert into uploadproduct (productname,productid,price,image)values('$nm','$pid','$prc','$fn')";
mysqli_query($cn,$q);
mysqli_close($cn);
echo"<script>alert('Product added successfully');window.location='index.php'</script>";
}
?>