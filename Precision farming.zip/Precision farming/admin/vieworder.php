<?php
include("header1.php");
?>

<h1 align=center>Recent Orders</h1>
 <table class="table">
    <thead>
      <tr>
        
        <th>Productid</th>
        <th>Quantity</th>
        <th>Price</th>
      </tr>
    </thead>
    <tbody>
<?php
include("connection.php");

$rs=mysqli_query($cn,"select * from buy");
while($a=mysqli_fetch_array($rs))
{
 extract($a);

echo "<tr><td>$Productid</td><td>$quantity</td><td>$price</td></tr>";
}
?>
    </tbody>
  </table>
<?php
include("footer.php");
?>